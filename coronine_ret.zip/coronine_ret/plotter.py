import numpy as np 
import matplotlib.pyplot as plt 

one = np.zeros(40)
two = np.zeros(40)
three = np.zeros(40)
four = np.zeros(40)
five = np.zeros(40)
six = np.zeros(40)
seven = np.zeros(40)
for x in range(0,16):
	A = np.loadtxt('_'.join([str(x+1),'nm_eigen.txt']))
	one[x] = A[47]
	two[x] = A[46]
	three[x] = A[45]
	four[x] = A[44]
	five[x] = A[43]
	six[x] = A[42]
	seven[x] = A[41]

for x in range(16,17):
	A = np.loadtxt('_'.join([str(x+1),'nm_eigen.txt']))
	one[x] = A[47]
	two[x] = A[46]
	three[x] = A[45]
	four[x] = A[44]
	five[x] = A[42]
	six[x] = A[41]
	seven[x] = A[43]

for x in range(17,19):
	A = np.loadtxt('_'.join([str(x+1),'nm_eigen.txt']))
	one[x] = A[46]
	two[x] = A[47]
	three[x] = A[44]
	four[x] = A[43]
	five[x] = A[42]
	six[x] = A[41]
	seven[x] = A[45]

for x in range(19,22):
	A = np.loadtxt('_'.join([str(x+1),'nm_eigen.txt']))
	one[x] = A[46]
	two[x] = A[45]
	three[x] = A[42]
	four[x] = A[41]
	five[x] = A[44]
	six[x] = A[43]
	seven[x] = A[47]

for x in range(22,23):
	A = np.loadtxt('_'.join([str(x+1),'nm_eigen.txt']))
	one[x] = A[46]
	two[x] = A[43]
	three[x] = A[42]
	four[x] = A[41]
	five[x] = A[44]
	six[x] = A[45]
	seven[x] = A[47]

for x in range(23,28):
	A = np.loadtxt('_'.join([str(x+1),'nm_eigen.txt']))
	one[x] = A[44]
	two[x] = A[43]
	three[x] = A[42]
	four[x] = A[41]
	five[x] = A[46]
	six[x] = A[45]
	seven[x] = A[47]

for x in range(28,29):
	A = np.loadtxt('_'.join([str(x+1),'nm_eigen.txt']))
	one[x] = A[44]
	two[x] = A[41]
	three[x] = A[42]
	four[x] = A[43]
	five[x] = A[46]
	six[x] = A[45]
	seven[x] = A[47]

for x in range(29,40):
	A = np.loadtxt('_'.join([str(x+1),'nm_eigen.txt']))
	one[x] = A[42]
	two[x] = A[41]
	three[x] = A[44]
	four[x] = A[43]
	five[x] = A[46]
	six[x] = A[45]
	seven[x] = A[47]

r = np.arange(1,41)
plt.plot(r,one,'-',r,two,'-',r,three,'-',r,four,'-',r,five,'-',r,six,'-',r,seven,'-',linewidth=3)
plt.show()

'''for x in range(10,20):
	A = np.loadtxt('_'.join([str(x+1),'nm_eigen.txt']))
	NSN[x] = A[25]
	N_S[x] = A[26]
	NNN[x] = A[27]'''