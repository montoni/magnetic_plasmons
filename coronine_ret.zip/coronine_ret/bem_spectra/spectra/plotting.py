import matplotlib.pyplot as plt
import numpy as np

spec = np.loadtxt('6mer_nm1')
eV = spec[:,0]
A_stat = spec[:,1]
B_stat = spec[:,2]
C_stat = spec[:,3]
A_ret = spec[:,4]
B_ret = spec[:,5]
C_ret = spec[:,6]

plt.plot(eV,A_ret,eV,B_ret,eV,C_ret,linewidth=3)
plt.legend(['top right','top center','mid left','middle'])
plt.show()