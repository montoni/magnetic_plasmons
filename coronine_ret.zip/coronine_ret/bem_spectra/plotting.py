import matplotlib.pyplot as plt
import numpy as np

spec = np.loadtxt('6mer_nm1')
eV = spec[:,0]
A_stat = spec[:,1]
B_stat = spec[:,2]
C_stat = spec[:,3]
D_stat = spec[:,4]
A_ret = spec[:,5]
B_ret = spec[:,6]
C_ret = spec[:,7]
D_ret = spec[:,8]

plt.plot(eV,A_stat,eV,B_stat,eV,C_stat,eV,D_stat,linewidth=3)
plt.legend(['top right','top center','mid left','middle'])
plt.show()